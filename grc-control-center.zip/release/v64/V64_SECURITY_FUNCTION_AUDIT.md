# v6.4 Security Function Audit

```json
{
  "generated_at": "2026-06-18T20:24:18.658Z",
  "migration_files_scanned": 45,
  "security_definer_functions_detected": 41,
  "findings_total": 34,
  "critical": 0,
  "high": 0,
  "medium": 34,
  "strict_passed": true,
  "note": "Static scan recognizes later ALTER FUNCTION ... SET search_path and REVOKE ALL ... FROM public. Review generated findings manually before production."
}
```

## Findings
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/003_rls_permissions_and_controls.sql / public.current_user_org_id: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/003_rls_permissions_and_controls.sql / public.current_user_org_id: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/003_rls_permissions_and_controls.sql / public.current_user_org_id: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/003_rls_permissions_and_controls.sql / public.current_user_org_id: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/003_rls_permissions_and_controls.sql / public.has_global_role: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/003_rls_permissions_and_controls.sql / public.can_access_scope: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/003_rls_permissions_and_controls.sql / public.can_manage_grc: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/006_workflow_queues_and_project_controls.sql / public.mark_overdue_work_items: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/006_workflow_queues_and_project_controls.sql / public.mark_overdue_work_items: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/006_workflow_queues_and_project_controls.sql / public.refresh_project_progress: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/007_escalation_and_governance_controls.sql / public.has_accepted_evidence: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/007_escalation_and_governance_controls.sql / public.create_escalation_if_missing: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/007_escalation_and_governance_controls.sql / public.refresh_escalation_events: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/007_escalation_and_governance_controls.sql / public.acknowledge_escalation_event: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/007_escalation_and_governance_controls.sql / public.acknowledge_escalation_event: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/009_access_control_and_role_governance.sql / has_active_role: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/009_access_control_and_role_governance.sql / has_active_role: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/009_access_control_and_role_governance.sql / has_active_role: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/009_access_control_and_role_governance.sql / deactivate_user_role: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/017_notifications_activity_timelines.sql / public.generate_due_reminders: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/018_qa_permission_deployment_readiness.sql / seed_default_qa_test_cases: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/022_ultra_release_restore_admin_dictionary.sql / start_restore_dry_run: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/022_ultra_release_restore_admin_dictionary.sql / start_restore_dry_run: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/023_enterprise_intelligence_reporting.sql / public.create_board_pack_snapshot: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/023_enterprise_intelligence_reporting.sql / public.record_backup_schedule_run: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/024_automation_intelligence_kri_reviews.sql / refresh_automation_intelligence: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/025_staging_validation_consolidation.sql / seed_staging_validation_defaults: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/026_finish_fast_release_sprint.sql / seed_final_release_defaults: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/034_v46_ovr_bilingual_rtl_production_hardening.sql / public.seed_v46_ovr_bilingual_rtl_defaults: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/036_b_ovr_workflow_controls.sql / public.can_close_ovr: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/036_b_ovr_workflow_controls.sql / public.can_close_ovr: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/036_b_ovr_workflow_controls.sql / public.create_ovr_corrective_action_project: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/040_v62_real_no_mock_data_layer.sql / public.seed_v62_real_no_mock_data_layer_defaults: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
- **medium** SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY in supabase/migrations/042_v64_database_security_proof.sql / public.v64_touch_updated_at: No REVOKE ALL ON FUNCTION ... FROM public found by static scan.
