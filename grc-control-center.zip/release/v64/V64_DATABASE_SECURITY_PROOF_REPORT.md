# v6.4 Database Security Proof Report

Generated: 2026-06-18T20:24:20.295Z

## Overall

```json
{
  "generated_at": "2026-06-18T20:24:20.295Z",
  "rls_static_strict_passed": true,
  "function_static_strict_passed": true,
  "view_static_strict_passed": true,
  "high_risk_findings": 0,
  "database_security_status": "static_ready_pending_staging_persona_sql",
  "warning": "Static readiness does not equal production proof. Run the SQL persona tests in staging."
}
```

## Audit summaries

### RLS static audit

```json
{
  "generated_at": "2026-06-18T20:24:18.087Z",
  "migration_files_scanned": 45,
  "created_tables_detected": 169,
  "tables_with_explicit_rls": 122,
  "tables_with_detected_policies": 120,
  "findings_total": 47,
  "critical": 0,
  "high": 0,
  "medium": 47,
  "strict_passed": true,
  "note": "Static audit only. Final proof requires applying migrations to staging and running supabase/tests/v64_persona_security_tests.sql."
}
```

### Security function audit

```json
{
  "generated_at": "2026-06-18T20:24:18.658Z",
  "migration_files_scanned": 45,
  "security_definer_functions_detected": 41,
  "findings_total": 34,
  "critical": 0,
  "high": 0,
  "medium": 34,
  "strict_passed": true,
  "note": "Static scan recognizes later ALTER FUNCTION ... SET search_path and REVOKE ALL ... FROM public. Review generated findings manually before production."
}
```

### View security audit

```json
{
  "generated_at": "2026-06-18T20:24:19.214Z",
  "migration_files_scanned": 45,
  "views_detected": 150,
  "findings_total": 102,
  "critical": 0,
  "high": 0,
  "medium": 102,
  "strict_passed": true,
  "note": "Static scan deduplicates views and recognizes later ALTER VIEW ... SET (security_invoker=true). Final proof still requires staging verification."
}
```

## High-risk findings

No high-risk static findings. Run staging SQL persona tests next.

## Required staging proof

- Apply migrations to a fresh Supabase staging database.
- Run `supabase/tests/v64_persona_security_tests.sql`.
- Test five real users: Admin, Super User, Audit, Manager, Employee.
- Attach SQL output to release evidence.
