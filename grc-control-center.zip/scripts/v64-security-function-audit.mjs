import fs from 'node:fs';
import path from 'node:path';

const strict = process.argv.includes('--strict');
const root = process.cwd();
const migrationsDir = path.join(root, 'supabase', 'migrations');
const outDir = path.join(root, 'release', 'v64');
fs.mkdirSync(outDir, { recursive: true });

const files = fs.existsSync(migrationsDir)
  ? fs.readdirSync(migrationsDir).filter((f) => f.endsWith('.sql')).sort().map((f) => path.join(migrationsDir, f))
  : [];

function normalizeFunctionName(name) {
  return (name || '')
    .replace(/^public\./i, '')
    .replace(/"/g, '')
    .trim()
    .toLowerCase();
}

const globalSearchPathFixes = new Set();
const globalRevokes = new Set();
const globalBroadGrants = [];

for (const file of files) {
  const sql = fs.readFileSync(file, 'utf8');
  for (const match of sql.matchAll(/alter\s+function\s+(?:if\s+exists\s+)?([a-zA-Z_][\w.]*)(?:\s*\([^)]*\))?\s+set\s+search_path\s*=/gi)) {
    globalSearchPathFixes.add(normalizeFunctionName(match[1]));
  }
  for (const match of sql.matchAll(/revoke\s+all\s+on\s+function\s+(?:if\s+exists\s+)?([a-zA-Z_][\w.]*)(?:\s*\([^)]*\))?\s+from\s+public/gi)) {
    globalRevokes.add(normalizeFunctionName(match[1]));
  }
  for (const match of sql.matchAll(/grant\s+execute\s+on\s+function\s+([^\s(]+)[\s\S]{0,250}\s+to\s+(public|authenticated)/gi)) {
    globalBroadGrants.push({ function_name: normalizeFunctionName(match[1]), role: match[2].toLowerCase() });
  }
}

const findings = [];
const functionBlocks = [];

for (const file of files) {
  const rel = path.relative(root, file).replaceAll('\\', '/');
  const sql = fs.readFileSync(file, 'utf8');
  const lower = sql.toLowerCase();
  const secDefMatches = [...lower.matchAll(/security\s+definer/g)];
  for (const match of secDefMatches) {
    const start = Math.max(0, match.index - 1200);
    const end = Math.min(sql.length, match.index + 1600);
    const block = sql.slice(start, end);
    const fnMatch = block.match(/create\s+(?:or\s+replace\s+)?function\s+([a-zA-Z_][\w.]*)/i);
    const function_name = fnMatch?.[1] || 'unknown_function_near_security_definer';
    const normalized = normalizeFunctionName(function_name);
    const hasSearchPath = /set\s+search_path\s*=/i.test(block) || /set_config\s*\(\s*'search_path'/i.test(block) || globalSearchPathFixes.has(normalized);
    const hasRevoke = new RegExp(`revoke\\s+all\\s+on\\s+function[\\s\\S]{0,400}${function_name.replace('.', '\\.')}`, 'i').test(sql)
      || /revoke\s+all\s+on\s+function/i.test(block)
      || globalRevokes.has(normalized);
    functionBlocks.push({ file: rel, function_name, has_search_path: hasSearchPath, has_public_revoke: hasRevoke });
    if (!hasSearchPath) {
      findings.push({ severity: 'high', code: 'SECURITY_DEFINER_NO_SEARCH_PATH', file: rel, function_name, message: 'SECURITY DEFINER function should set a fixed search_path.' });
    }
    if (!hasRevoke) {
      findings.push({ severity: 'medium', code: 'SECURITY_DEFINER_EXECUTE_NOT_REVOKED_NEARBY', file: rel, function_name, message: 'No REVOKE ALL ON FUNCTION ... FROM public found by static scan.' });
    }
  }
}

for (const grant of globalBroadGrants) {
  const globallyRevoked = globalRevokes.has(grant.function_name);
  if (grant.role === 'public' && !globallyRevoked) {
    findings.push({ severity: 'critical', code: 'BROAD_FUNCTION_EXECUTE_GRANT', function_name: grant.function_name, role: grant.role, message: 'Privileged function may be executable by public.' });
  } else if (grant.role === 'authenticated' && !globallyRevoked) {
    findings.push({ severity: 'high', code: 'BROAD_FUNCTION_EXECUTE_GRANT', function_name: grant.function_name, role: grant.role, message: 'Privileged function may be executable by all authenticated users.' });
  }
}

const summary = {
  generated_at: new Date().toISOString(),
  migration_files_scanned: files.length,
  security_definer_functions_detected: functionBlocks.length,
  findings_total: findings.length,
  critical: findings.filter((f) => f.severity === 'critical').length,
  high: findings.filter((f) => f.severity === 'high').length,
  medium: findings.filter((f) => f.severity === 'medium').length,
  strict_passed: findings.filter((f) => ['critical', 'high'].includes(f.severity)).length === 0,
  note: 'Static scan recognizes later ALTER FUNCTION ... SET search_path and REVOKE ALL ... FROM public. Review generated findings manually before production.'
};

fs.writeFileSync(path.join(outDir, 'v64-security-function-audit.json'), JSON.stringify({ summary, functionBlocks, globalSearchPathFixes: [...globalSearchPathFixes], globalRevokes: [...globalRevokes], findings }, null, 2));
fs.writeFileSync(path.join(outDir, 'V64_SECURITY_FUNCTION_AUDIT.md'), `# v6.4 Security Function Audit\n\n\`\`\`json\n${JSON.stringify(summary, null, 2)}\n\`\`\`\n\n## Findings\n${findings.map((f) => `- **${f.severity}** ${f.code} in ${f.file || 'migration scan'} / ${f.function_name}: ${f.message}`).join('\n') || 'No critical/high findings detected.'}\n`);
console.log('v6.4 security function audit complete.');
console.log(JSON.stringify(summary, null, 2));
if (strict && !summary.strict_passed) {
  console.error('v6.4 strict function audit failed.');
  process.exit(1);
}
