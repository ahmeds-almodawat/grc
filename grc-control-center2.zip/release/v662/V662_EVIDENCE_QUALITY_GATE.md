# v6.6.2 Evidence Quality Gate

Generated: 2026-06-18T21:53:33.394Z

Status: **not_ready_manual_evidence_required**

| Evidence file | Passed | Reason |
|---|---:|---|
| `staging-migration-log.txt` | ❌ | missing |
| `01-v64-persona-sql-output.txt` | ❌ | missing |
| `02-v65-workflow-sql-output.txt` | ❌ | missing |
| `03-v66-pilot-evidence-sql-output.txt` | ❌ | missing |
| `restore-dryrun-evidence.txt` | ❌ | missing |
| `pilot-signoff.md` | ❌ | missing |

## Important

This checks attachment quality signals only. Final approval still requires human review of the evidence content.
