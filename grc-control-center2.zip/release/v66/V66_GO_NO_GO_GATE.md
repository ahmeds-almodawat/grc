# v6.6 Go / No-Go Gate

```json
{
  "generated_at": "2026-06-18T20:24:34.809Z",
  "controlled_pilot_status": "not_ready_manual_evidence_required",
  "strict_passed": false,
  "gates": [
    {
      "id": "local_typecheck_build",
      "status": "passed"
    },
    {
      "id": "v60_no_mock_strict",
      "status": "evidence_present"
    },
    {
      "id": "v64_static_security",
      "status": "not_verified"
    },
    {
      "id": "v65_real_tests",
      "status": "evidence_present"
    },
    {
      "id": "manual_staging_evidence",
      "status": "manual_required"
    }
  ],
  "missing_manual_evidence": [
    {
      "id": "fresh_staging_migrations_001_044",
      "title": "Fresh staging Supabase migrations applied through 044",
      "status": "manual_required",
      "evidence_needed": "Screenshot/log showing migrations 001 through 044 applied successfully in staging."
    },
    {
      "id": "staging_persona_sql_v64",
      "title": "v64 persona SQL tests passed in staging",
      "status": "manual_required",
      "evidence_needed": "Result/output from supabase/tests/v64_persona_security_tests.sql."
    },
    {
      "id": "staging_workflow_sql_v65",
      "title": "v65 workflow SQL smoke tests passed in staging",
      "status": "manual_required",
      "evidence_needed": "Result/output from supabase/tests/v65_workflow_smoke_tests.sql."
    },
    {
      "id": "backup_restore_dryrun",
      "title": "Backup and restore dry-run completed in staging",
      "status": "manual_required",
      "evidence_needed": "Restore source, restore target, table counts, evidence-storage sample, smoke-test result, issue/signoff."
    },
    {
      "id": "ovr_confidentiality_no_real_patient_data",
      "title": "OVR confidentiality rule confirmed for pilot",
      "status": "manual_required",
      "evidence_needed": "Quality/IT confirmation that pilot will not include real patient identifiers or confidential OVR details until persona proof passes."
    },
    {
      "id": "pilot_signoff_it_quality_admin",
      "title": "IT, Quality, and Admin pilot signoff completed",
      "status": "manual_required",
      "evidence_needed": "Signed v66 pilot signoff file with names/dates."
    }
  ],
  "recommendation": "Use only for controlled internal testing until missing manual staging evidence is attached."
}
```
