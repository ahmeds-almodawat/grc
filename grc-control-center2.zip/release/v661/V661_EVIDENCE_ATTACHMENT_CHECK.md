# v6.6.1 Evidence Attachment Check

Generated: 2026-06-18T21:32:29.515Z

Evidence folder: `release\v66\evidence-attachments`

- Required: **6**
- Attached: **0**
- Missing: **6**

## Checklist

### ❌ Fresh staging migrations applied through 045

- ID: `staging-migration-log`
- Status: **missing**
- Matched files: none
- Example filenames: `staging-migration-log.txt`, `staging-migration-screenshot.png`

### ❌ v64 persona SQL tests passed

- ID: `v64-persona-sql-output`
- Status: **missing**
- Matched files: none
- Example filenames: `01-v64-persona-sql-output.txt`

### ❌ v65 workflow SQL smoke tests passed

- ID: `v65-workflow-sql-output`
- Status: **missing**
- Matched files: none
- Example filenames: `02-v65-workflow-sql-output.txt`

### ❌ v66 controlled pilot evidence SQL tests passed

- ID: `v66-pilot-evidence-sql-output`
- Status: **missing**
- Matched files: none
- Example filenames: `03-v66-pilot-evidence-sql-output.txt`

### ❌ Restore dry-run evidence completed

- ID: `restore-dryrun-evidence`
- Status: **missing**
- Matched files: none
- Example filenames: `restore-dryrun-evidence.txt`, `restore-dryrun-screenshot.png`

### ❌ IT / Quality / Admin signoff attached

- ID: `pilot-signoff`
- Status: **missing**
- Matched files: none
- Example filenames: `pilot-signoff.md`, `quality-it-admin-signoff.pdf`

