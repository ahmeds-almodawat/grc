# v6.6.2 Staging Evidence Capture Pack

Add-only helper pack for staging evidence capture.

## Replace files

None.

## Add files

- `scripts/v662-install-evidence-capture-scripts.mjs`
- `scripts/v662-staging-command-pack.mjs`
- `scripts/v662-evidence-template-generator.mjs`
- `scripts/v662-evidence-quality-gate.mjs`
- `docs/V662_STAGING_EVIDENCE_CAPTURE_GUIDE.md`
- `PATCH_NOTES.md`

## Commands

```bash
node scripts/v662-install-evidence-capture-scripts.mjs
npm run v662:all
```

After real evidence is attached:

```bash
npm run v662:strict-proof
```

## Safety

This pack does not modify runtime code, migrations, tests, package lock, auth, or RLS. It only generates runbooks, templates, and evidence quality checks.
